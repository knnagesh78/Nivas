# Nivas — mobile and interactive dashboard update

## What is included

- Student, Warden, and Admin login pages and home dashboards now share their role-specific interactive 3D models: the student robot, warden shield/key, and admin command cube.
- Drag with a mouse or swipe horizontally with a finger to rotate. Tap the scene or its action button to play the role animation. Vertical scrolling and pinch zoom remain available.
- Arrow buttons and keyboard arrows rotate; Enter/Space plays the animation; R or the reset button restores the view.
- The student robot closes its eyes while a password field is focused. Forms retain cursor lighting, raised buttons, and touch/focus feedback.
- Login uses a compact phone layout with role tabs above a full-width scene and form.
- Dashboard scenes stack above two-column quick activities on phones. Warden/Admin metrics use two columns; detailed Student cards stack vertically.
- Activity buttons, form controls, and navigation have larger touch targets. Notification panels fit the phone viewport. Tables scroll inside their panels.
- Activity cards have entrance animation, cursor depth, and touch highlights. Detailed Student cards keep a stable surface for their nested controls.
- Installed-app layouts account for notches, home indicators, changing viewport height, and portrait/landscape orientation. Bottom navigation hides while dashboard text fields are focused to leave more room for typing.
- Touch devices use a capped pixel ratio, approximately 30-fps animation budget, and no dynamic shadow rendering. Only the selected role model is created initially. Scenes pause when off-screen or the app is hidden.
- Motion on/off and system reduced-motion preferences remain available. Manual scene rotation remains available with motion paused.
- Light/dark dashboard themes remain supported. Admin now uses violet accents to match its login scene.
- Existing authentication and dashboard business logic are preserved.

## Replace files in your project

1. Extract this ZIP. Open its `Nivas-main` folder.
2. Copy the complete included `src` folder into the matching folder in your local Nivas project. Replace matching files and include all new files.
3. Replace the project-root `index.html` with the included one.
4. Replace `public/manifest.json` with the included version in the same location.
5. Commit and push these changes using your usual GitHub workflow, then deploy the updated project.

Keep your existing Firebase environment values and deployment configuration. No dependency changes or file deletions are needed. Upload the extracted source files, not the ZIP itself. The archive contains the complete project and earlier improvements.

Already-installed mobile copies will need the updated deployment before they can show this version. This ZIP does not change your live app by itself.

## Run locally

```sh
npm ci
npm run dev
```

Create a production build with:

```sh
npm run build
```

## Validation and limits

The production build passed. Source comparisons confirmed dashboard edits were limited to presentation attributes and classes, and login handlers, authentication context, and dependency files are unchanged. Standalone display, safe-area viewport settings, and orientation configuration were checked in source. The existing gesture-state checks from the previous revision cover tap/drag, vertical-scroll handling, cancellation, secondary-pointer isolation, rotation bounds, and reset.

The build reports a Three.js chunk-size advisory (about 560 kB before compression). Physical-device gestures, installed Android/iPhone rendering, browser layout, live Firebase operations, and PWA updates have not been tested. This version has not been pushed to GitHub or deployed.
